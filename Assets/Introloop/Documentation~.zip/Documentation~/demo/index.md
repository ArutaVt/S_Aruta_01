# Demo

## Prebuilt players

Let's see how well it performs by yourself. You can download built players for some platforms here even before purchasing this package.

![Introloop demo](images/demo.png)

- [Windows (15.92MB)](https://firebasestorage.googleapis.com/v0/b/exceed7-web.appspot.com/o/Introloop%2FIntroloopWindows.zip?alt=media&token=440d22f8-b1d4-4fe2-b9ce-25a70e3d2683)
- [macOS (18.82 MB)](https://firebasestorage.googleapis.com/v0/b/exceed7-web.appspot.com/o/Introloop%2FIntroloopMacOS.app.zip?alt=media&token=acf5439f-94e0-4381-913b-6347441b0076)
- [Android (23.08 MB)](https://firebasestorage.googleapis.com/v0/b/exceed7-web.appspot.com/o/Introloop%2FIntroloopAndroid.zip?alt=media&token=1a06fe23-ef5c-4d15-a7c9-be7a804df780)

The demo is basically a bunch of buttons, each button represent one C# method call on the `IntroloopPlayer`.

A column of white buttons on the right represents `Play` method on various `IntroloopAudio`, each with possibly different settings in it. I have provided some short songs and 1 longer song for you to test. (Song with **A** is meant to be followed by song with **B**.)

Dark panel on the left provides some debug informations. Remember that 1 `IntroloopPlayer` = 2 `IntroloopTrack` = 4 `AudioSource`.

Checking **Use Fade** will use fade parameter on `Play` on button push, with `fadeTimeSeconds` argument adjustable with slider. You can test the transition between different playback mode with and without fades. Colored button does what it says.

"Remember and stop" button will remember the time before stopping. Any next audio you play will start from this time number. To reset the remembered time, use the regular Stop button once.

If you are not using touch device, you can also press letters in the bracket on your keyboard to activate button. Feel free to mash and stress test Introloop!

## Demo scenes

If you bought the plugin, you could use the `/Samples~` folder in the package. It contains the same 3 scenes as that prebuilt player.

### With Unity Package Manager (2019.1+)

After you use UPM to link to the package, you can see the import samples button. Press it and you will get the sample in your own project. You may [read this](https://forum.unity.com/threads/samples-in-packages-manual-setup.623080/) for details how it works.

![Samples UPM](images/samples-upm.png)

After, you will see a folder chain `Samples/` appearing in your project. It is wrapped nicely in a package name and even in a [SemVer version](https://semver.org/) of the package. This is actually in your game project, as opposed to the package which could be linked.

![Samples imported](images/samples-import.png)

After you are done you can safely delete the whole imported `Samples/Introloop`, all in one place without worrying "is there anything else to delete?".

This is how Samples works in modern Unity. They will stay hidden in the package (`/Samples~` folder of the package), until you want to see them **by importing** to your game.

The plugin package itself can still be linked via UPM without polluting your game's `Assets` folder, only the samples requires importing. In a way this shows that the sample works from a user's perspective. (i.e. "you can do this too")

### Without Unity Package Manager

Unity skips importing `/Samples~` folder [because of trailing `~`](https://docs.unity3d.com/Manual/SpecialFolders.html). You can go inside here **with your file explorer** in your OS and copy the content out to your project.

![Samples copy](images/samples-copy.png)

## Introloop in the real world

If you want to see Introloop in a real application, my own game [Duel Otters](https://duelotters.com/) which you can freely download to your iOS/Android device is heavily powered by it. Introloop has gone through many frustrating bug fixes throughout this game's development so I am quite confident now that it is working well.

In that game all BGMs are Introloop, and the actual length is quite short (only 5-10 seconds) but with Introloop they sounded longer than it actually is. This is great because I can conserve space while still having many songs.