# Q & A

#### How to change the pitch dynamically, in real time?

Unfortunately that is not possible with Introloop. Getting scheduling to work with constant pitch change is already complicated! If that is going to be possible in the future, it needs to reschedule on **every bits of pitch change** and I think that's not a good idea for accuracy and performance. What if the pitch change happen right before the seam and the new schedule could not be fulfilled?

#### Can I import time cues/loop points from my wav file header?

No, Introloop works on what imported `AudioClip` gives. As long as `AudioClip` doesn't include that information Introloop couldn't use it either.

#### What about multiple loop points that I could somehow "script" it to go in order?

Currently Introloop has only 2 loop points. I do have some idea how "`ScriptedIntroloopAudio`" could work by having any number of loop points, and you could specify a looping sequence for it to go through. Or even set some kind of boolean so that the next time it arrives at a certain loop point, it will go to a different place. (For raising tension of the music, in sync, based on some conditions from the game.)

I doubt there are much demand for this niche feature on top of already nich plugin like this, but I do want it for myself. For example, I could make a music that loops the exact same 3 bars then go to final bar with cymbal and transition, with an audio file that contains only 1 bar and that final bar for extreme game size optimization.

But this will make it very awkward for the composer that he compose a full music, but when exporting he must carefully export only one of each repeating part. And it won't make sense as a single `AudioClip` file anymore. Probably we need something new like `AudioParts` that we can assign multiple `AudioClip` instead so we could save space. In the end, this feels like an entirely new system than what would fit in Introloop.

But these are likely not in this near future. Not when the [DOTS Audio](https://forum.unity.com/threads/dots-audio-discussion.651982/) is being worked on and I think I could use it when the API is fully fledged out. I could do that all completely on thread for you if I wait for the API! I am working on a new audio plugin that is feature parity with external audio engine. For example, you could use a timeline to script sequences of audio. That plugin likely could do what I described and priced higher than Introloop which is only for specific purpose. Those feature would use DOTS Audio API, I don't know if I could port them to be based on "scheduled" API for Introloop.

#### My previous `GameObject` that was in the template prefab (`Resources`) folder is suddenly missing scripts.

In version 4.0.0 the component `IntroloopSettings` are now a regular serializable `class`, and it is now inside `IntroloopPlayer`. The missing component is likely `IntroloopSettings` and you could safely delete it. Unfortunately the mixer asset you had set up has to be connected again on the field of `IntroloopPlayer`.

#### My singleton player is suddenly missing an `AudioMixerGroup`

In version 5.0.0 I have changed how the `AudioMixerGroup` must be set to an `AudioSource` "template" component attaced near the `IntroloopPlayer`. Go to your template prefab's location (`Resources/Introloop/`) then add `AudioSource` component, then add an `AudioMixerGroup` to that. At runtime it will be copied to your instantiated singleton.

#### How to hide the Scene view icon of IntroloopPlayer?

Click on "Gizmos" in your Scene tab, and then **left click on the icon image, not on the little arrow or the checkbox**. It will be greyed out and disappear from the scene view.

#### What kind of things can mess up Introloop's scheduling?

Introloop uses [`AudioSettings.dspTime`](http://docs.unity3d.com/ScriptReference/AudioSettings-dspTime.html) for scheduling audio pieces, which is independent of normal game's clock. This means if you implement [`Time.timeScale`](http://docs.unity3d.com/ScriptReference/Time-timeScale.html) for pausing the game or for some other reason, it will have no effect on Introloop and it will continue playing. (You can have music still playing while the game pause, for example.)

However there are some situations that can mess up the timing and can produce weird behaviours. For example when creating games in Unity and Introloop is playing, if you make the Unity window inactive everything will stop and resume nicely (The playing audio, [`AudioSettings.dspTime`](http://docs.unity3d.com/ScriptReference/AudioSettings-dspTime.html) and [`Time.time`](http://docs.unity3d.com/ScriptReference/Time-time.html))

On the other hand if you do things like right-clicking on any `GameObject` in your Hierarchy and keep the popup menu open, you will notice that your game stopped updating but the music still plays. This will cause Introloop to miss the schedule and I can't fix it because OS-level behaviour is not in my control. **This kind of behaviour can only happen in the Editor** though, so you should not have to worry about it in real game.

Lastly, "scheduled" methods works on DSP time. Things like `AudioListener.pause = true;` will completely stop all scheduling as well.

#### Now that I use an IntroloopAudio to play audio, will Introloop still respect AudioClip import settings?

Yes, because `IntroloopAudio` is just a link to the original audio. As long as "scheduled" methods works on `AudioSource` and `AudioClip`, you are going to get all the clip's import settings.

#### I'm sure my boundaries are dead exact but I can still hear a bit of discontinuity in the game!

Actually even the time with 3 decimal places is not enough, since the actual unit for location in audio is **sample**. The time will be converted to sample by Unity, and this is where an audio might slip off a few samples producing an audible seams.

I use time in seconds since it is easier to get and in most case produce good result. But if your audio is not seamless (and you are sure that your time is exact), you can try adding very small number to both boundaries **by the same amount**. Since the audio bits after the boundaries should sound the same, doing this should not change the song at all but you will get a new transition point. This new seam might work out better than the previous point. Try this several times to find out the best spot. (Remember the original point too! You can't go back more than that.)

#### I want to use "samples" unit instead of "seconds" on specifying loop points for accuracy

We can't, the first reason is that [`PlayScheduled`](https://docs.unity3d.com/ScriptReference/AudioSource.PlayScheduled.html) that Introloop is utilizing is using seconds. I want to use the same unit as what is the most accurate method of playing in Unity.

I can make it so your samples converts to seconds. Sameples sounded super-accurate but it depends on sample rate. And in Unity you can change sampling rate of an imported `AudioClip` at will, not to mention the engine may do it anyways like in Android that it sounds like 24000Hz at runtime. So your hard coded samples is now wrong as your song could ended up having more or less samples depending on this settings.

#### When will this be usable with WebGL build?

This limitation is actually on Unity's side. [This page lists current limitations](https://docs.unity3d.com/Manual/webgl-audio.html). It says scheduling methods **are supported**, but when I test it the `PlayScheduled` method always start audio from the beginning. So the information in that page are **wrong**.

Even in 2019 WebGL still cannot do scheduling. I don't know when will we able to do it.

#### Is there a way to change a track's volume in real time?

Introloop uses 4 `AudioSource` in tandem, and changes their volume for crossfading, etc. regulary so it is not easy to directly manipulate them. For global volume/sfx that you might adjust in option screen, the current best practice is using the Audio Mixer. You can route Introloop's audio to your mixer by following [this tutorial](http://www.exceed7.com/introloop/getting-started.html).

After this, the level of that track you routed to can be controlled from script. Mainly via `SetFloat/GetFloat` which you can then link to your slider UI. [More info](https://unity3d.com/learn/tutorials/modules/beginner/5-pre-order-beta/exposed-audiomixer-parameters).


#### How could Introloop accurately loop the music? As I understand Unity Update API will respond only as quickly as the next frame update.](#)

Introloop does not split the music clip or buffer data at any point. You are correct about Unity's Update API, but Unity has an another timing mechanism specifically for audio, [dspTime](https://docs.unity3d.com/ScriptReference/AudioSettings-dspTime.html).

There are 3 methods that utilize this, `AudioSource.PlayScheduled`, `SetScheduledStartTime`, and `SetScheduledEndTime`. After you call them, when dspTime comes to that point you specify an audio will play regardless of if it is in-between Update frame or not. Therefore I can set it up to loop to itself without cutting the asset. (Actually it is not looping to itself but a duplicate of itself that is waiting at the seam. When dspTime arrives one will stop and the other one will begin.)

The difficulties of using this is it is like setting a trap. You have to plan things ahead of time to also allows it to loads up the audio. Introloop's strategy is to schedule when there is halfway to go approaching the loop point. The schedule cannot be cancelled, if user decides to stop, pause or change music in the period after it already scheduled we also have to reschedule to override the old ones. The schedule can even be met while an `AudioSource` is stopping or pausing but luckily will not take effect until it is playing again, so we can reschedule before resuming to prevent it jumping to a wrong place. Lastly, with pitch all scheduling calculations will have to be scaled accordingly since `dspTime` don't know a thing about the speed which audio plays.