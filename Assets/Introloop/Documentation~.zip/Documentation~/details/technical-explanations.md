# Technical Explanations

They are useful if you want to go deep and modify the source code or just want to know some history back to 2015 when Introloop was first released...

#### Whats the difference between I write an simple script to monitor the playback time and set to start point when it reaches the loop end point?
    
Is that "simple script" to monitor works on `Update`? It will not trigger exactly at the loop point in that case since it is frame-based. There is no way the frame updates exactly the moment you want to "stitch" the audio.

Instead we need the scheduling trio : [this](https://docs.unity3d.com/ScriptReference/AudioSource.PlayScheduled.html), [this](https://docs.unity3d.com/ScriptReference/AudioSource.SetScheduledEndTime.html), and [this](https://docs.unity3d.com/ScriptReference/AudioSource.SetScheduledStartTime.html) to plan ahead of time when to start-stop each source. These methods cannot make start/stop occur immediately, **but precisely in the future**.

Introloop is a plugin that holds 4 `AudioSource` and do all 3 scheduled calls for you at an appropriate time to make it transition from intro to loop, and from loop to loop again, all within a single coherent `AudioClip`.

#### I need to modify the code. Can you explain the inner workings of Introloop so that I can get started?

The **IntroloopPlayer** `GameObject` that appears when you call `IntroloopPlayer.Instance.xxxx` contains 2 `IntroloopTrack`.

Each `IntroloopTrack` represent one `IntroloopAudio` and we needed 2 because when cross-fading we must hear 2 audio at the same time at some point. Each call to `Play` method, Introloop will alternate between these two `IntroloopTrack`.

One `IntroloopTrack` contains 2 Unity's `AudioSource` so in total Introloop achieve it's playback function with 4 `AudioSource`. We need 2 `AudioSource` because of intro and looping functionality. When approaching loop point, the other `AudioSource` will be scheduled and waiting to take the baton from previous one, while the previous one is also scheduled to stop at the same time. The scheduling is accurate because it uses [`AudioSettings.dspTime`](http://docs.unity3d.com/ScriptReference/AudioSettings-dspTime.html) function in Unity which is independent from game's timescale. Scheduling will happen when one `AudioSource` is reaching halfway til the switching point.

Each `AudioSource` actually loads the same audio data (from the same `IntroloopAudio`) so memory usage is **not** doubled.

#### Memory footprint of Introloop

The memory overhead will be the same as Unity's normal audio loading and playing, as it is basically just 4 AudioSources that loads the same audio. This means the memory depends on your import settings of the said audio. (Thus "Streaming" would use the least memory as it loads just around the playhead.) You can determine the memory overhead by dragging your 3.5MB 32-bit song to the AudioSource (with your desired loading type) and look at the Profiler. (Beware that just clicking the file might cause a false memory overhead as the Profiler profiles memories used for previewing in the editor)

Other than that, the additional memory overhead is from storing the GameObjects and variables that manages the looping mechanism. I don't think that is significant compared to the audio data itself.

However Introloop does something more that are different from just issuing `.Play()` `.Stop()` directly to the `AudioSource` :

1.  When you stop the audio (and the audio finished fading out completely, if you choose to stop with a fade out), it is automatically unloaded from memory. This is not the case when you just call `Stop` to the AudioSource. This is in effect if you choose "Decompress on load" or "Compressed in memory" type.
2.  If you cross fade the audio, there will be a moment when both audio are in memory. This means if both audio file has "Decompress On Load" you will have the whole size of 2 audios in the memory in that cross fading moment. However, when it finished cross fading the faded out ones will be automatically unloaded. If your memory allowance is very critical you might want to avoid the cross fading by fading out the first song then begin playing the second song later.


#### Why Introloop requires Unity 5 and above? Will it works in Unity 4.x with some restrictions?

I am sorry to say that no, it won't work! Read on for detailed reasons that I have been fighting with since 4.x era.

I finished Introloop a long time ago and have been using it in my projects both personal and at work. However the reason I cannot put in on store is because there are much more problems in 4.x about memory that I will explain shortly.

In Unity 4.x if we connect `IntroloopAudio` to the inspector like we did now in Unity 5, since it contains reference to `AudioClip`, all the songs will be instantly loaded into memory even if you are not going to play it yet. The same happen when you connect `AudioClip` to `public AudioClip` inspector variable. When scene start it checks all inspector slots and load everything. Even if you use `Resources.Unload(resource)` to quickly free it, the unavoidable memory spike at scene load certainly can crash mobile project with low amount of RAM. (It did really happen to me)

In Unity 5.x if you click any `AudioClip` you will notice some new checkboxes that is not present in Unity 4.x, **Preload Audio Data** and **Load In Background** (Corresponding to the new scripting counterpart [`AudioClip.preloadAudioData`](http://docs.unity3d.com/ScriptReference/AudioClip-preloadAudioData.html) and [`AudioClip.loadInBackground`](http://docs.unity3d.com/ScriptReference/AudioClip-loadInBackground.html) respectively.) The first one is godsend, since if you **uncheck** it the audio will not load unless you call the new [`AudioClip.LoadAudioData()`](http://docs.unity3d.com/ScriptReference/AudioClip.LoadAudioData.html) (In Unity 4.x it works like this is set to **true** all the times.) And so it enables us to use Unity's workflow of connecting the inspector.

How about ditching the connect thing and put the `IntroloopAudio` in the **Resoources** folder and load it dynamically in Unity 4.x? Yes, the memory spike is no more but it requires that all your audio is in **Resources** folder and loaded through `Resources.Load(string)`. This **Resources** folder restriction feels unnatural and difficult to explain to others and also makes your project messy. (But I have been doing this personally before Unity 5.0) Moreover `Resources.Load(string)` is designed for run-time execution, it is string based which is not flexible like normal asset-to-inspector preconnecting in Unity. Not to mention that `Resources.Unload(resource)` is too low-level, sometimes it doesn't unload because something is using the resource and even produce errors. The only error-free way to unload is [`Resources.UnloadUnusedAssets()`](http://docs.unity3d.com/ScriptReference/Resources.UnloadUnusedAssets.html) but it traverse all `GameObject` in your scene and it is very bad for performance. (A plugin should never reach out of its own thing also.)

In Unity 5.x to free audio we finally have a dedicated [`AudioClip.UnloadAudioData()`](http://docs.unity3d.com/ScriptReference/AudioClip.UnloadAudioData.html) (Counterpart of also new [`AudioClip.LoadAudioData()`](http://docs.unity3d.com/ScriptReference/AudioClip.LoadAudioData.html)) and it is much more reliable than `Resource.Unload(resource)`. The new **Load In Background** option is not mandatory for Introloop but also useful. In Unity 4.x your code will block when loading audio (Combine that with the must-load-all-connected-audio problem and you get a lag everytime a scene loads!). Checking this to **true** and your code will continue running while it loads! As an extra, in Unity 5.x the Profiler reports audio data more truthfully. (I have gone through hell being tricked repeatedly in 4.x already...)

For these reasons, if you try Introloop in Unity 4.x it will not compile since it is missing aforementioned 5.x functions.