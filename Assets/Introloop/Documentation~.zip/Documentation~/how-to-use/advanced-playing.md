# Advanced Playing

## Multiple singletons : subclassing from `IntroloopPlayer<T>`

With `IntroloopPlayer.Instance.Play`, it refers to the same "Instance" throughout your game. Meaning that you cannot have 2 concurrent singleton Introloop player playing and looping at the same time.

You can create a subclass like this : `public class DemoSubclassPlayer : IntroloopPlayer<DemoSubclassPlayer> { ...` (Please put **itself** in the generic just like that) Then you will gain a new singleton static accessor on your class : `.Get`

With `DemoSubclassPlayer.Get`, it works like `IntroloopPlayer.Instance` but will spawns a new singleton named by you! This means you can now have many Introloop playing at the same time while maintaining convenience of a singleton.

![Different singleton](images/different-singleton.png)

It is useful for dividing the players into several parts. Like `BGMPlayer`, `AmbientPlayer`, etc. You could have a looping BGM with intro, playing along with seamlessly looping wind sound all with their own singleton access point.

Moreover, you can then define your own methods on your subclass to be more suitable for your game. Like `FieldBGMPlayer.Get.PlayDesertTheme()` instead of `IntroloopPlayer.Instance.Play(desertTheme);`.

**You need to prepare a new prefab template file named after your class**. If your class name is `DemoSubclassPlayer` then to use the template prefab it must be named **DemoSubclassPlayer** in `Resources/Introloop` folder. You can have a different `AudioMixerGroup` set in `AudioSource` from the default singleton this way.

![Template subclass](images/template-subclass.png)

Note the template prefab name which must be the same as your class's name.

You can see a neat trick :  Other than having a completely different `AudioSource` template with different and weirder setup to inherit like `spatialBlend` of `0.05`, we can now even declare and connect all the `IntroloopAudio` assets we wish to play on the subclassed component! (Not as a reference on any scene.)

The singleton will spawn with them connected, your `FieldBGMPlayer.Get.PlayDesertTheme()` that maybe inside then works without any argument because it is connected on itself and the code of this method is hardwired to it.

See the **IntroloopDemo-SubclassedSingleton** [demo scene](../demo/index.md) if you have any trouble setting this up.

![Introloop subclass demo](images/subclass-demo.png)

## Positional `IntroloopPlayer` on the scene

`IntroloopPlayer` does not need to be strictly a singleton nor 2D source, though that is the most common use case for introlooping music.

If you manually create a `GameObject` with `IntroloopPlayer` and a template `AudioSource` **on the scene**, at runtime you will see an underlying 4 `AudioSource` spawned under it exactly the same way when you used the singleton or subclassed singleton.

Therefore you can think of it as a single `AudioSource` that could introloop. You can position it anywhere. Imagine a TV object in the game's scene which you want to play an audio with intro then loop at a later part. If you setup the template `AudioSource` to have a spatial mode 3D (with any falloff curve you want) then it could get louder or quieter as `AudioListener` get close to it or away from it. This is when you may want `priority` as not 0, because it is not a music and works like regular `AudioSource`.

Alternatively you can also call `AddComponent<IntroloopPlayer>` to dynamically create the player and the children will be spawned the same way on its next `Start()`. If you add `AudioSource` to it right after and set things up before the `Start()` of `IntroloopPlayer` arrives the next frame, you can make it in time for the template `AudioSource` to take effect. If you are late, you can still set things on the template `AudioSource` then call on the player component `player.TemplateSource` then `player.ApplyAudioSourceCharacteristics(templateSource)` to apply as many times as you like.

These local Introloop players **do not** automatically get `DontDestroyOnLoad` like `IntroloopPlayer.Instance` or `Subclass.Get` ones, thus they will stop playing if you change scene with `LoadSceneMode.Single`, etc.

This might be confusing, so see the **IntroloopDemo-Positional** [demo scene](../demo/index.md) if you have any trouble setting this up.

![Introloop local positional demo](images/local-positional-demo.png)

Sphere on the left has `IntroloopPlayer` component waiting on it already, the one on the right gets an `IntroloopPlayer` added at runtime. Both sphere works equally as a positional Introloop source.